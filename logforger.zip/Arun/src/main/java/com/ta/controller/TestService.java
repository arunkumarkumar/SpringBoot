package com.ta.controller;

import org.springframework.stereotype.Service;

@Service
public class TestService {
	public int add(int number1, int number2) {

		int addition = number1 + number2;
		return addition;

	}

	public int sub(int number1, int number2) {

		int subtraction = number1 - number2;

		return subtraction;

	}

	public int mul(int number1, int number2) {

		int multiplication = number1 * number2;

		return multiplication;

	}

	public int div(int number1, int number2) {

		int division = number1 / number2;

		return division;

	}

}
