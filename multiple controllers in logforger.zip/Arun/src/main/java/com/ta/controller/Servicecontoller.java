package com.ta.controller;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/var/")
public class Servicecontoller {
	@Value("${filepath}")
	private String filepath;
	@Autowired TestService objTestService;
		@RequestMapping(value = "loadproperty", method = RequestMethod.GET)
		public ResponseEntity<?> loadproperty(@RequestParam Map <String,String>  request) throws Exception {
			int ans=0;
			Logger log = LogManager.getLogger("kumar");
			System.out.println("Started"+filepath);
			try {

				log.debug("testAPI started: " + request);
				log.info("testAPI started: " + request);
				System.out.println(request);
				String operation=request.get("objTestService").toString();
				int number1=Integer.parseInt(request.get("number1").toString());
				int number2=Integer.parseInt(request.get("number2").toString());
				switch(operation) {
				case "add":
				     ans= objTestService.add(number1,number2);
				break;
				case "sub":
				ans= objTestService.sub(number1,number2);
				break;
				case "mul":
				ans= objTestService.mul(number1,number2);
				break;
				case "div":
				ans= objTestService.div(number1,number2);
				break;
				
			}
			}
			catch(Exception e) {
				System.out.println(e);
				
				
			}
			System.out.println("ended"+filepath);
			return new ResponseEntity<>(request, HttpStatus.OK);

			}

}
